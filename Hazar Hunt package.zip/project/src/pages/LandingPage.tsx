import { useNavigate } from 'react-router-dom';
import { BookOpen, Play, ShieldAlert, AlertTriangle, Flame } from 'lucide-react';
import ParticleBackground from '../components/ParticleBackground';

const LOGO = '/Altasnim_Logo.png';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/30 relative overflow-hidden">
      <ParticleBackground />

      {/* Floating hazard icons */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <ShieldAlert className="absolute top-[12%] left-[8%] w-12 h-12 text-amber-200 animate-float-slow" />
        <ShieldAlert className="absolute top-[18%] right-[12%] w-10 h-10 text-orange-200 animate-float-medium" />
        <AlertTriangle className="absolute bottom-[20%] left-[15%] w-14 h-14 text-amber-100 animate-float-fast" />
        <Flame className="absolute bottom-[25%] right-[10%] w-11 h-11 text-orange-100 animate-float-slow" />
        <AlertTriangle className="absolute top-[45%] left-[5%] w-8 h-8 text-amber-100/60 animate-float-medium" />
        <ShieldAlert className="absolute top-[60%] right-[6%] w-9 h-9 text-orange-100/50 animate-float-fast" />
      </div>

      {/* Top bar */}
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO} alt="Al Tasnim" className="h-12 w-auto object-contain" />
          </div>
          <div className="hidden sm:block px-4 py-2 bg-white/80 backdrop-blur-sm border border-slate-200/60 rounded-full text-xs font-medium text-slate-500 shadow-sm">
            HSE Training Platform v2.0
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[calc(100vh-88px)] px-6 -mt-10">
        {/* Badge */}
        <div className="mb-8 px-5 py-2.5 bg-white/90 backdrop-blur-sm border border-amber-200/50 rounded-full shadow-lg shadow-amber-100/30 animate-fade-in">
          <span className="text-amber-700 font-semibold text-sm tracking-wider">
            INDUSTRIAL SAFETY EXCELLENCE
          </span>
        </div>

        {/* Main title */}
        <h1 className="text-center mb-4 animate-fade-in-up">
          <span className="block text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-extrabold text-slate-800 tracking-tight leading-none">
            HAZARD HUNT
          </span>
          <span className="block text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 bg-clip-text text-transparent mt-2 tracking-tight">
            TRAINING PROGRAM
          </span>
        </h1>

        {/* Subtitle */}
        <div className="mt-6 mb-12 text-center animate-fade-in-up-delay">
          <p className="text-lg sm:text-xl text-slate-500 font-medium mb-2">
            Al Tasnim ODC NIMR
          </p>
          <p className="text-sm sm:text-base text-slate-400 font-mono tracking-widest">
            C/31000000171
          </p>
        </div>

        {/* Decorative line */}
        <div className="w-24 h-1 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full mb-12 animate-fade-in" />

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-5 sm:gap-6 animate-fade-in-up-delay-2">
          <button
            onClick={() => navigate('/introduction')}
            className="group relative px-8 py-4 sm:px-10 sm:py-5 bg-white border-2 border-slate-200 rounded-2xl shadow-lg shadow-slate-100/50 hover:shadow-xl hover:shadow-amber-100/40 hover:border-amber-300 hover:scale-105 transition-all duration-300 ease-out"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-100 to-slate-50 group-hover:from-amber-50 group-hover:to-orange-50 flex items-center justify-center transition-colors duration-300">
                <BookOpen className="w-6 h-6 text-slate-600 group-hover:text-amber-600 transition-colors duration-300" />
              </div>
              <div className="text-left">
                <span className="block text-base sm:text-lg font-bold text-slate-800">Introduction / Objective</span>
                <span className="block text-xs text-slate-400 mt-0.5">Learn about the program</span>
              </div>
            </div>
          </button>

          <button
            onClick={() => navigate('/categories')}
            className="group relative px-8 py-4 sm:px-10 sm:py-5 bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl shadow-lg shadow-amber-500/25 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-105 transition-all duration-300 ease-out"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                <Play className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <span className="block text-base sm:text-lg font-bold text-white">Begin Training</span>
                <span className="block text-xs text-white/70 mt-0.5">Start your hazard hunt</span>
              </div>
            </div>
          </button>
        </div>

        {/* Bottom stats */}
        <div className="mt-16 flex items-center gap-8 text-center animate-fade-in-up-delay-2">
          <div>
            <p className="text-2xl font-bold text-slate-800">11</p>
            <p className="text-xs text-slate-400 mt-1">Categories</p>
          </div>
          <div className="w-px h-8 bg-slate-200" />
          <div>
            <p className="text-2xl font-bold text-amber-600">100%</p>
            <p className="text-xs text-slate-400 mt-1">Interactive</p>
          </div>
          <div className="w-px h-8 bg-slate-200" />
          <div>
            <p className="text-2xl font-bold text-slate-800">HSE</p>
            <p className="text-xs text-slate-400 mt-1">Certified</p>
          </div>
        </div>
      </div>
    </div>
  );
}
