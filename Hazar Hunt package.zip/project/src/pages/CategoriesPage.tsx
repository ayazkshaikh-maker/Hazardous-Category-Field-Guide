import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, HardHat, Building2, Cog, Zap, Flame, DoorOpen, Skull,
  ArrowUpFromLine, ClipboardCheck, Sparkles, CloudSun, Plus, Trash2,
  CheckCircle2, Shield, Loader2, Pencil, GripVertical, Wrench, Award
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { isAdminSession } from '../lib/adminAuth';
import { isCategoryCompleted, getCompletedCategoriesCount } from '../lib/progress';
import AdminModal from '../components/AdminModal';
import ProgressBar from '../components/ProgressBar';

interface Category {
  id: string;
  name: string;
  icon: string;
  order_index: number;
}

const iconMap: Record<string, React.ElementType> = {
  Building2, Cog, Zap, Flame, DoorOpen, Skull, ArrowUpFromLine,
  ClipboardCheck, Sparkles, CloudSun, HardHat, Wrench, Crane: Wrench,
};

const LOGO = '/Altasnim_Logo.png';

export default function CategoriesPage() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(isAdminSession());
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminAction, setAdminAction] = useState<'add' | 'edit' | 'delete' | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('HardHat');
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [deletingCat, setDeletingCat] = useState<Category | null>(null);

  async function fetchCategories() {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('order_index', { ascending: true });
    if (data) setCategories(data);
    setLoading(false);
  }

  useEffect(() => { fetchCategories(); }, []);

  function requireAdmin(action: 'add' | 'edit' | 'delete', cat?: Category) {
    if (isAdmin) {
      setAdminAction(action);
      if (action === 'edit' && cat) {
        setEditingCat(cat);
        setNewCatName(cat.name);
        setNewCatIcon(cat.icon);
      }
      if (action === 'delete' && cat) setDeletingCat(cat);
      return;
    }
    setAdminAction(action);
    if (action === 'edit' && cat) setEditingCat(cat);
    if (action === 'delete' && cat) setDeletingCat(cat);
    setShowAdminModal(true);
  }

  function handleAdminAuth() {
    setIsAdmin(true);
    setShowAdminModal(false);
  }

  async function handleAddCategory() {
    if (!newCatName.trim()) return;
    await supabase.from('categories').insert({
      name: newCatName.trim(),
      icon: newCatIcon,
      order_index: categories.length,
    });
    setNewCatName('');
    setNewCatIcon('HardHat');
    setAdminAction(null);
    fetchCategories();
  }

  async function handleEditCategory() {
    if (!editingCat || !newCatName.trim()) return;
    await supabase.from('categories')
      .update({ name: newCatName.trim(), icon: newCatIcon })
      .eq('id', editingCat.id);
    setEditingCat(null);
    setNewCatName('');
    setNewCatIcon('HardHat');
    setAdminAction(null);
    fetchCategories();
  }

  async function handleDeleteCategory() {
    if (!deletingCat) return;
    await supabase.from('categories').delete().eq('id', deletingCat.id);
    setDeletingCat(null);
    setAdminAction(null);
    fetchCategories();
  }

  const completedCount = getCompletedCategoriesCount();
  const availableIcons = Object.keys(iconMap);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/20">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={() => navigate('/')} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium text-sm">Home</span>
          </button>
          <img src={LOGO} alt="Al Tasnim" className="h-10 w-auto object-contain" />
          <div className="flex items-center gap-3">
            {isAdmin && (
              <span className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-semibold text-amber-700 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Admin
              </span>
            )}
            {!isAdmin && (
              <button
                onClick={() => setShowAdminModal(true)}
                className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all flex items-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5" /> Admin
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10">
        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-800 mb-3">Training Categories</h1>
          <p className="text-slate-500 max-w-lg mx-auto">Select a category to begin your hazard identification training.</p>
        </div>

        {/* Progress */}
        <div className="max-w-md mx-auto mb-10">
          <ProgressBar current={completedCount} total={categories.length} label="Overall Progress" />
        </div>

        {/* Admin add button */}
        {isAdmin && (
          <div className="flex justify-center mb-8 gap-3">
            <button
              onClick={() => { setAdminAction('add'); setNewCatName(''); setNewCatIcon('HardHat'); }}
              className="flex items-center gap-2 px-5 py-2.5 bg-amber-500 text-white font-semibold rounded-xl hover:bg-amber-600 transition-colors shadow-md shadow-amber-500/20"
            >
              <Plus className="w-4 h-4" /> Add Category
            </button>
          </div>
        )}

        {/* Add/Edit modal */}
        {(adminAction === 'add' || adminAction === 'edit') && isAdmin && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 space-y-5">
              <h3 className="text-lg font-bold text-slate-800">
                {adminAction === 'add' ? 'Add New Category' : 'Edit Category'}
              </h3>
              <input
                type="text"
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                placeholder="Category name"
                className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-slate-800"
                autoFocus
              />
              <div>
                <p className="text-sm text-slate-600 mb-2 font-medium">Select Icon</p>
                <div className="flex flex-wrap gap-2">
                  {availableIcons.map((iconName) => {
                    const Icon = iconMap[iconName];
                    return (
                      <button
                        key={iconName}
                        onClick={() => setNewCatIcon(iconName)}
                        className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${newCatIcon === iconName ? 'bg-amber-500 text-white shadow-md' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}
                      >
                        <Icon className="w-5 h-5" />
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => { setAdminAction(null); setEditingCat(null); }}
                  className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-600 font-medium hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={adminAction === 'add' ? handleAddCategory : handleEditCategory}
                  className="flex-1 py-2.5 bg-amber-500 text-white font-semibold rounded-xl hover:bg-amber-600 transition-colors"
                >
                  {adminAction === 'add' ? 'Add' : 'Save'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete confirmation */}
        {adminAction === 'delete' && isAdmin && deletingCat && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6 space-y-4 text-center">
              <div className="w-14 h-14 mx-auto bg-red-50 rounded-full flex items-center justify-center">
                <Trash2 className="w-7 h-7 text-red-500" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Delete Category?</h3>
              <p className="text-sm text-slate-500">
                "{deletingCat.name}" and all its scenarios will be permanently removed.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => { setAdminAction(null); setDeletingCat(null); }}
                  className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-600 font-medium hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteCategory}
                  className="flex-1 py-2.5 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Categories grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {categories.map((cat) => {
              const Icon = iconMap[cat.icon] || HardHat;
              const completed = isCategoryCompleted(cat.id);
              return (
                <div key={cat.id} className="group relative">
                  <button
                    onClick={() => navigate(`/category/${cat.id}`)}
                    className={`w-full text-left p-6 rounded-2xl border transition-all duration-300 hover:scale-[1.03] hover:shadow-xl ${completed
                      ? 'bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200 hover:shadow-emerald-100/50'
                      : 'bg-white border-slate-100 hover:shadow-amber-100/40 hover:border-amber-200'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-14 h-14 rounded-xl flex items-center justify-center transition-all duration-300 ${completed
                        ? 'bg-gradient-to-br from-emerald-500 to-green-500'
                        : 'bg-gradient-to-br from-slate-100 to-slate-50 group-hover:from-amber-100 group-hover:to-orange-50'
                      }`}>
                        <Icon className={`w-7 h-7 ${completed ? 'text-white' : 'text-slate-500 group-hover:text-amber-600'} transition-colors duration-300`} />
                      </div>
                      {completed && <CheckCircle2 className="w-6 h-6 text-emerald-500" />}
                    </div>
                    <h3 className="font-bold text-slate-800 mb-1 text-sm sm:text-base leading-tight">{cat.name}</h3>
                    <p className="text-xs text-slate-400">
                      {completed ? 'Completed' : 'Click to start'}
                    </p>
                  </button>
                  {isAdmin && (
                    <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                      <button
                        onClick={(e) => { e.stopPropagation(); requireAdmin('edit', cat); }}
                        className="w-7 h-7 bg-white rounded-lg shadow-sm border border-slate-200 flex items-center justify-center hover:bg-amber-50 transition-colors"
                      >
                        <Pencil className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); requireAdmin('delete', cat); }}
                        className="w-7 h-7 bg-white rounded-lg shadow-sm border border-slate-200 flex items-center justify-center hover:bg-red-50 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-500" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Certificate button */}
        {completedCount > 0 && (
          <div className="text-center mt-12 pb-8">
            <button
              onClick={() => navigate('/certificate')}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-2xl shadow-lg shadow-amber-500/25 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-105 transition-all duration-300"
            >
              <Award className="w-5 h-5" />
              Issue Certificate
            </button>
            {completedCount < categories.length && (
              <p className="text-xs text-slate-400 mt-3">Complete all categories for full certification</p>
            )}
          </div>
        )}
      </div>

      <AdminModal
        isOpen={showAdminModal}
        onClose={() => { setShowAdminModal(false); setAdminAction(null); }}
        onAuthenticated={handleAdminAuth}
      />
    </div>
  );
}
