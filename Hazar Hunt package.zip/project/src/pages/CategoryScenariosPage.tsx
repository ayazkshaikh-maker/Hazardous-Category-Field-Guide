import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Pencil, Eye, EyeOff, Maximize2, X, ChevronLeft, ChevronRight, Shield, HardHat, Loader2, AlertTriangle, CheckCircle2, FileText, ShieldCheck, HardHat as PPEIcon, Wrench, BookOpen, Upload, Image as ImageIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { isAdminSession } from '../lib/adminAuth';
import { markScenarioViewed, markCategoryCompleted, isScenarioViewed } from '../lib/progress';
import AdminModal from '../components/AdminModal';
import ProgressBar from '../components/ProgressBar';

const LOGO = '/Altasnim_Logo.png';

interface Scenario {
  id: string;
  category_id: string;
  title: string;
  description: string;
  unsafe_explanation: string;
  safe_explanation: string;
  lessons_learned: string;
  hazard_indicators: string;
  ppe_requirements: string;
  control_measures: string;
  unsafe_image_url: string;
  safe_image_url: string;
  order_index: number;
}

interface Category {
  id: string;
  name: string;
  icon: string;
}

export default function CategoryScenariosPage() {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const [category, setCategory] = useState<Category | null>(null);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showSafe, setShowSafe] = useState(false);
  const [fullscreenImg, setFullscreenImg] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(isAdminSession());
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingScenario, setEditingScenario] = useState<Scenario | null>(null);
  const [deletingScenario, setDeletingScenario] = useState<Scenario | null>(null);
  const [formData, setFormData] = useState({
    title: '', description: '', unsafe_explanation: '', safe_explanation: '',
    lessons_learned: '', hazard_indicators: '', ppe_requirements: '', control_measures: '',
    unsafe_image_url: '', safe_image_url: '',
  });

  async function fetchData() {
    if (!categoryId) return;
    const [catRes, scenRes] = await Promise.all([
      supabase.from('categories').select('*').eq('id', categoryId).maybeSingle(),
      supabase.from('scenarios').select('*').eq('category_id', categoryId).order('order_index'),
    ]);
    if (catRes.data) setCategory(catRes.data);
    if (scenRes.data) setScenarios(scenRes.data);
    setLoading(false);
  }

  useEffect(() => { fetchData(); }, [categoryId]);

  useEffect(() => { setShowSafe(false); }, [currentIndex]);

  const currentScenario = scenarios[currentIndex];
  const viewedCount = scenarios.filter((s) => isScenarioViewed(s.id)).length;

  function handleViewScenario() {
    if (currentScenario) {
      markScenarioViewed(currentScenario.id);
      const newViewedCount = scenarios.filter((s) => isScenarioViewed(s.id)).length;
      if (newViewedCount === scenarios.length && scenarios.length > 0 && categoryId) {
        markCategoryCompleted(categoryId);
      }
    }
  }

  function handleRevealSafe() {
    setShowSafe(true);
    handleViewScenario();
  }

  function openAddForm() {
    if (!isAdmin) { setShowAdminModal(true); return; }
    setFormData({
      title: '', description: '', unsafe_explanation: '', safe_explanation: '',
      lessons_learned: '', hazard_indicators: '', ppe_requirements: '', control_measures: '',
      unsafe_image_url: '', safe_image_url: '',
    });
    setEditingScenario(null);
    setShowAddForm(true);
  }

  function openEditForm(s: Scenario) {
    if (!isAdmin) { setShowAdminModal(true); return; }
    setFormData({
      title: s.title, description: s.description,
      unsafe_explanation: s.unsafe_explanation, safe_explanation: s.safe_explanation,
      lessons_learned: s.lessons_learned, hazard_indicators: s.hazard_indicators,
      ppe_requirements: s.ppe_requirements, control_measures: s.control_measures,
      unsafe_image_url: s.unsafe_image_url, safe_image_url: s.safe_image_url,
    });
    setEditingScenario(s);
    setShowAddForm(true);
  }

  async function handleSaveScenario() {
    if (!formData.title.trim() || !categoryId) return;
    if (editingScenario) {
      await supabase.from('scenarios').update({ ...formData }).eq('id', editingScenario.id);
    } else {
      await supabase.from('scenarios').insert({
        ...formData, category_id: categoryId, order_index: scenarios.length,
      });
    }
    setShowAddForm(false);
    setEditingScenario(null);
    fetchData();
  }

  async function handleDeleteScenario() {
    if (!deletingScenario) return;
    await supabase.from('scenarios').delete().eq('id', deletingScenario.id);
    setDeletingScenario(null);
    if (currentIndex >= scenarios.length - 1 && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
    fetchData();
  }

  function updateForm(field: string, value: string) {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/20">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={() => navigate('/categories')} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium text-sm">Categories</span>
          </button>
          <div className="flex items-center gap-3">
            <img src={LOGO} alt="Al Tasnim" className="h-9 w-auto object-contain hidden sm:block" />
            <h2 className="font-bold text-slate-800 text-sm sm:text-base truncate">
              {category?.name || 'Category'}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <span className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-semibold text-amber-700 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Admin
              </span>
            )}
            {!isAdmin && (
              <button onClick={() => setShowAdminModal(true)} className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Admin
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Progress */}
        <div className="max-w-md mx-auto mb-8">
          <ProgressBar current={viewedCount} total={scenarios.length} label="Scenarios Viewed" />
        </div>

        {/* Admin buttons */}
        {isAdmin && (
          <div className="flex justify-center mb-6">
            <button onClick={openAddForm} className="flex items-center gap-2 px-5 py-2.5 bg-amber-500 text-white font-semibold rounded-xl hover:bg-amber-600 transition-colors shadow-md shadow-amber-500/20">
              <Plus className="w-4 h-4" /> Add Scenario
            </button>
          </div>
        )}

        {scenarios.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 mx-auto bg-slate-100 rounded-2xl flex items-center justify-center mb-4">
              <FileText className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-lg font-bold text-slate-600 mb-2">No Scenarios Yet</h3>
            <p className="text-slate-400 text-sm">
              {isAdmin ? 'Click "Add Scenario" to create the first scenario.' : 'No training scenarios have been added to this category yet.'}
            </p>
          </div>
        ) : currentScenario && (
          <>
            {/* Scenario navigation */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <button
                onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
                disabled={currentIndex === 0}
                className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center disabled:opacity-30 hover:bg-slate-50 transition-all"
              >
                <ChevronLeft className="w-5 h-5 text-slate-600" />
              </button>
              <span className="text-sm font-semibold text-slate-600">
                Scenario {currentIndex + 1} of {scenarios.length}
              </span>
              <button
                onClick={() => setCurrentIndex(Math.min(scenarios.length - 1, currentIndex + 1))}
                disabled={currentIndex === scenarios.length - 1}
                className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center disabled:opacity-30 hover:bg-slate-50 transition-all"
              >
                <ChevronRight className="w-5 h-5 text-slate-600" />
              </button>
            </div>

            {/* Scenario title + admin controls */}
            <div className="text-center mb-6">
              <div className="flex items-center justify-center gap-3">
                <h3 className="text-xl sm:text-2xl font-bold text-slate-800">{currentScenario.title}</h3>
                {isAdmin && (
                  <div className="flex gap-1">
                    <button onClick={() => openEditForm(currentScenario)} className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center hover:bg-amber-100 transition-colors">
                      <Pencil className="w-4 h-4 text-amber-600" />
                    </button>
                    <button onClick={() => setDeletingScenario(currentScenario)} className="w-8 h-8 rounded-lg bg-red-50 flex items-center justify-center hover:bg-red-100 transition-colors">
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                )}
              </div>
              {currentScenario.description && (
                <p className="text-slate-500 mt-2 max-w-2xl mx-auto text-sm">{currentScenario.description}</p>
              )}
              {isScenarioViewed(currentScenario.id) && (
                <div className="inline-flex items-center gap-1.5 mt-3 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-semibold text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Viewed
                </div>
              )}
            </div>

            {/* Image comparison */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Unsafe */}
              <div className="bg-white rounded-2xl border border-red-100 shadow-sm overflow-hidden">
                <div className="px-5 py-3 bg-red-50 border-b border-red-100 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  <span className="font-bold text-red-700 text-sm">UNSAFE CONDITION</span>
                </div>
                <div className="p-4">
                  {currentScenario.unsafe_image_url ? (
                    <div className="relative group cursor-pointer" onClick={() => setFullscreenImg(currentScenario.unsafe_image_url)}>
                      <img
                        src={currentScenario.unsafe_image_url}
                        alt="Unsafe condition"
                        className="w-full h-64 sm:h-80 object-cover rounded-xl"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-xl flex items-center justify-center">
                        <Maximize2 className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  ) : (
                    <div className="w-full h-64 sm:h-80 bg-red-50 rounded-xl flex flex-col items-center justify-center">
                      <ImageIcon className="w-12 h-12 text-red-200 mb-2" />
                      <span className="text-red-300 text-sm">No image uploaded</span>
                    </div>
                  )}
                  {currentScenario.unsafe_explanation && (
                    <p className="mt-3 text-sm text-slate-600 leading-relaxed">{currentScenario.unsafe_explanation}</p>
                  )}
                </div>
              </div>

              {/* Safe */}
              <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm overflow-hidden">
                <div className="px-5 py-3 bg-emerald-50 border-b border-emerald-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span className="font-bold text-emerald-700 text-sm">SAFE CONDITION</span>
                  </div>
                  {!showSafe && (
                    <button
                      onClick={handleRevealSafe}
                      className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500 text-white rounded-lg text-xs font-semibold hover:bg-emerald-600 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" /> Reveal
                    </button>
                  )}
                </div>
                <div className="p-4">
                  {showSafe ? (
                    <>
                      {currentScenario.safe_image_url ? (
                        <div className="relative group cursor-pointer" onClick={() => setFullscreenImg(currentScenario.safe_image_url)}>
                          <img
                            src={currentScenario.safe_image_url}
                            alt="Safe condition"
                            className="w-full h-64 sm:h-80 object-cover rounded-xl animate-fade-in"
                          />
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-xl flex items-center justify-center">
                            <Maximize2 className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </div>
                      ) : (
                        <div className="w-full h-64 sm:h-80 bg-emerald-50 rounded-xl flex flex-col items-center justify-center animate-fade-in">
                          <ImageIcon className="w-12 h-12 text-emerald-200 mb-2" />
                          <span className="text-emerald-300 text-sm">No image uploaded</span>
                        </div>
                      )}
                      {currentScenario.safe_explanation && (
                        <p className="mt-3 text-sm text-slate-600 leading-relaxed animate-fade-in">{currentScenario.safe_explanation}</p>
                      )}
                    </>
                  ) : (
                    <div className="w-full h-64 sm:h-80 bg-slate-50 rounded-xl flex flex-col items-center justify-center">
                      <EyeOff className="w-12 h-12 text-slate-200 mb-2" />
                      <span className="text-slate-300 text-sm">Click "Reveal" to see the safe condition</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Details cards */}
            {(currentScenario.lessons_learned || currentScenario.hazard_indicators || currentScenario.ppe_requirements || currentScenario.control_measures) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {currentScenario.lessons_learned && (
                  <DetailCard icon={BookOpen} title="Lessons Learned" text={currentScenario.lessons_learned} color="amber" />
                )}
                {currentScenario.hazard_indicators && (
                  <DetailCard icon={AlertTriangle} title="Key Hazard Indicators" text={currentScenario.hazard_indicators} color="red" />
                )}
                {currentScenario.ppe_requirements && (
                  <DetailCard icon={PPEIcon} title="PPE Requirements" text={currentScenario.ppe_requirements} color="blue" />
                )}
                {currentScenario.control_measures && (
                  <DetailCard icon={Wrench} title="Control Measures" text={currentScenario.control_measures} color="emerald" />
                )}
              </div>
            )}

            {/* Scenario dots */}
            <div className="flex items-center justify-center gap-2 flex-wrap mb-8">
              {scenarios.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setCurrentIndex(i)}
                  className={`w-3 h-3 rounded-full transition-all ${i === currentIndex
                    ? 'bg-amber-500 scale-125'
                    : isScenarioViewed(s.id)
                      ? 'bg-emerald-400'
                      : 'bg-slate-200 hover:bg-slate-300'
                  }`}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Fullscreen image */}
      {fullscreenImg && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setFullscreenImg(null)}>
          <button className="absolute top-4 right-4 w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
            <X className="w-6 h-6 text-white" />
          </button>
          <img src={fullscreenImg} alt="Fullscreen" className="max-w-full max-h-full object-contain rounded-xl" />
        </div>
      )}

      {/* Add/Edit form modal */}
      {showAddForm && isAdmin && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm overflow-y-auto">
          <div className="min-h-screen flex items-start justify-center py-10 px-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-800">
                  {editingScenario ? 'Edit Scenario' : 'Add New Scenario'}
                </h3>
                <button onClick={() => { setShowAddForm(false); setEditingScenario(null); }} className="text-slate-400 hover:text-slate-600">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <FormField label="Title" value={formData.title} onChange={(v) => updateForm('title', v)} />
              <FormField label="Description" value={formData.description} onChange={(v) => updateForm('description', v)} multiline />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField label="Unsafe Image URL" value={formData.unsafe_image_url} onChange={(v) => updateForm('unsafe_image_url', v)} placeholder="https://..." />
                <FormField label="Safe Image URL" value={formData.safe_image_url} onChange={(v) => updateForm('safe_image_url', v)} placeholder="https://..." />
              </div>
              <FormField label="Unsafe Condition Explanation" value={formData.unsafe_explanation} onChange={(v) => updateForm('unsafe_explanation', v)} multiline />
              <FormField label="Safe Condition Explanation" value={formData.safe_explanation} onChange={(v) => updateForm('safe_explanation', v)} multiline />
              <FormField label="Lessons Learned" value={formData.lessons_learned} onChange={(v) => updateForm('lessons_learned', v)} multiline />
              <FormField label="Key Hazard Indicators" value={formData.hazard_indicators} onChange={(v) => updateForm('hazard_indicators', v)} multiline />
              <FormField label="PPE Requirements" value={formData.ppe_requirements} onChange={(v) => updateForm('ppe_requirements', v)} multiline />
              <FormField label="Control Measures" value={formData.control_measures} onChange={(v) => updateForm('control_measures', v)} multiline />

              <div className="flex gap-3 pt-2">
                <button onClick={() => { setShowAddForm(false); setEditingScenario(null); }} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-600 font-medium hover:bg-slate-50 transition-colors">
                  Cancel
                </button>
                <button onClick={handleSaveScenario} className="flex-1 py-2.5 bg-amber-500 text-white font-semibold rounded-xl hover:bg-amber-600 transition-colors">
                  {editingScenario ? 'Save Changes' : 'Add Scenario'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deletingScenario && isAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6 space-y-4 text-center">
            <div className="w-14 h-14 mx-auto bg-red-50 rounded-full flex items-center justify-center">
              <Trash2 className="w-7 h-7 text-red-500" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Delete Scenario?</h3>
            <p className="text-sm text-slate-500">"{deletingScenario.title}" will be permanently removed.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeletingScenario(null)} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-600 font-medium hover:bg-slate-50 transition-colors">
                Cancel
              </button>
              <button onClick={handleDeleteScenario} className="flex-1 py-2.5 bg-red-500 text-white font-semibold rounded-xl hover:bg-red-600 transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      <AdminModal isOpen={showAdminModal} onClose={() => setShowAdminModal(false)} onAuthenticated={() => { setIsAdmin(true); setShowAdminModal(false); }} />
    </div>
  );
}

function DetailCard({ icon: Icon, title, text, color }: { icon: React.ElementType; title: string; text: string; color: string }) {
  const colorMap: Record<string, string> = {
    amber: 'bg-amber-50 border-amber-100 text-amber-700',
    red: 'bg-red-50 border-red-100 text-red-700',
    blue: 'bg-blue-50 border-blue-100 text-blue-700',
    emerald: 'bg-emerald-50 border-emerald-100 text-emerald-700',
  };
  const iconColorMap: Record<string, string> = {
    amber: 'text-amber-500',
    red: 'text-red-500',
    blue: 'text-blue-500',
    emerald: 'text-emerald-500',
  };
  return (
    <div className={`rounded-xl border p-4 ${colorMap[color]}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 ${iconColorMap[color]}`} />
        <h4 className="font-bold text-sm">{title}</h4>
      </div>
      <p className="text-sm opacity-80 leading-relaxed">{text}</p>
    </div>
  );
}

function FormField({ label, value, onChange, multiline, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; multiline?: boolean; placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={3}
          className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-slate-800 text-sm resize-none"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-slate-800 text-sm"
        />
      )}
    </div>
  );
}
