import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Target, Eye, Brain, Users, ShieldCheck, BookOpen, Award,
  ChevronDown, ChevronUp, Play
} from 'lucide-react';

const LOGO = '/Altasnim_Logo.png';

const objectives = [
  {
    icon: Target,
    title: 'Training Objective',
    content: 'To equip all personnel with the knowledge and skills to proactively identify, assess, and control workplace hazards before they result in incidents, injuries, or environmental damage.',
  },
  {
    icon: Eye,
    title: 'Hazard Awareness Goals',
    content: 'Develop a keen eye for recognizing unsafe conditions and unsafe acts across all work environments. Understand the difference between hazards, risks, and controls in industrial operations.',
  },
  {
    icon: Brain,
    title: 'Behavioral Safety Concepts',
    content: 'Promote a safety-first mindset where every worker takes ownership of safety. Understand how human behavior influences workplace safety and learn techniques to identify at-risk behaviors.',
  },
  {
    icon: Users,
    title: 'Unsafe vs Safe Philosophy',
    content: 'Learn to compare unsafe conditions with their safe counterparts through visual scenarios. Understand why certain conditions are hazardous and what corrective actions are required.',
  },
  {
    icon: ShieldCheck,
    title: 'Multilingual Workforce Learning',
    content: 'Designed for multinational workforce environments, this program uses visual-first learning methods ensuring comprehension across language barriers through images, icons, and interactive scenarios.',
  },
  {
    icon: BookOpen,
    title: 'Interactive Learning Approach',
    content: 'Engage with real-world scenarios through image-based hazard identification. Compare unsafe and safe conditions, learn corrective measures, and earn certification upon completion.',
  },
];

export default function IntroductionPage() {
  const navigate = useNavigate();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/20">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium text-sm">Back to Home</span>
          </button>
          <div className="flex items-center gap-3">
            <img src={LOGO} alt="Al Tasnim" className="h-10 w-auto object-contain" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10">
        {/* Page title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200/50 rounded-full mb-4">
            <BookOpen className="w-4 h-4 text-amber-600" />
            <span className="text-amber-700 text-sm font-semibold">Program Overview</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-800 mb-4">
            Introduction & Objective
          </h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-base sm:text-lg">
            Understand the purpose, goals, and methodology of the Hazard Hunt Training Program.
          </p>
        </div>

        {/* Objectives grid */}
        <div className="grid gap-4 mb-16 max-w-4xl mx-auto">
          {objectives.map((obj, i) => {
            const Icon = obj.icon;
            const isExpanded = expandedIndex === i;
            return (
              <div
                key={i}
                className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden"
              >
                <button
                  onClick={() => setExpandedIndex(isExpanded ? null : i)}
                  className="w-full flex items-center gap-4 p-5 text-left"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors duration-300 ${isExpanded ? 'bg-gradient-to-br from-amber-500 to-orange-500' : 'bg-slate-50'}`}>
                    <Icon className={`w-6 h-6 transition-colors duration-300 ${isExpanded ? 'text-white' : 'text-slate-500'}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-800 text-base sm:text-lg">{obj.title}</h3>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                  )}
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${isExpanded ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}
                >
                  <p className="px-5 pb-5 text-slate-600 leading-relaxed text-sm sm:text-base pl-[4.5rem]">
                    {obj.content}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Certificate Preview */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200/50 rounded-full mb-4">
              <Award className="w-4 h-4 text-amber-600" />
              <span className="text-amber-700 text-sm font-semibold">Certificate Preview</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-2">
              Earn Your Certificate
            </h2>
            <p className="text-slate-500">
              Upon successful completion, you will receive a professionally issued HSE certificate.
            </p>
          </div>

          {/* Certificate card */}
          <div className="bg-white rounded-2xl border-2 border-[#2b3d6b]/20 shadow-xl shadow-slate-200/40 p-1">
            <div className="border-2 border-[#e88c2a]/20 rounded-xl p-6 sm:p-10 relative overflow-hidden">
              {/* Watermark */}
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.04] pointer-events-none">
                <img src={LOGO} alt="" className="w-80 h-80 object-contain" />
              </div>

              <div className="relative text-center space-y-5">
                {/* Logo */}
                <div className="flex items-center justify-center mb-2">
                  <img src={LOGO} alt="Al Tasnim" className="h-16 w-auto object-contain" />
                </div>

                <p className="text-xs tracking-[0.3em] text-[#2b3d6b]/60 font-semibold uppercase">
                  Al Tasnim ODC NIMR C/31000000171
                </p>

                <h3 className="text-2xl sm:text-3xl font-extrabold text-[#2b3d6b] tracking-tight">
                  CERTIFICATE OF COMPLETION
                </h3>

                <p className="text-sm text-slate-500 max-w-md mx-auto">
                  This is to certify that the following individual has successfully completed the
                  Hazard Hunt Training Program.
                </p>

                <div className="py-3">
                  <div className="w-64 mx-auto border-b-2 border-dashed border-[#e88c2a]/40" />
                  <p className="text-xs text-slate-400 mt-2 italic">Trainee Name</p>
                </div>

                <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto text-xs">
                  <div>
                    <p className="text-slate-400">Date</p>
                    <p className="font-semibold text-[#2b3d6b]">--/--/----</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Score</p>
                    <p className="font-semibold text-[#2b3d6b]">--%</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Cert. No.</p>
                    <p className="font-semibold text-[#2b3d6b]">------</p>
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-center gap-8">
                  <div className="text-center">
                    <div className="w-32 border-b border-[#2b3d6b]/30 mb-1" />
                    <p className="text-xs text-slate-400">HSE Lead</p>
                  </div>
                  {/* Golden foil seal */}
                  <div className="relative w-16 h-16">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-600 shadow-lg shadow-amber-400/30" />
                    <div className="absolute inset-[3px] rounded-full bg-gradient-to-br from-yellow-200 via-amber-300 to-yellow-500 flex items-center justify-center">
                      <div className="text-center">
                        <Award className="w-5 h-5 text-amber-800 mx-auto" />
                        <p className="text-[5px] font-extrabold text-amber-900 mt-0.5 tracking-widest">CERTIFIED</p>
                      </div>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="w-32 border-b border-[#2b3d6b]/30 mb-1" />
                    <p className="text-xs text-slate-400">Project Manager</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center pb-10">
          <button
            onClick={() => navigate('/categories')}
            className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-2xl shadow-lg shadow-amber-500/25 hover:shadow-xl hover:shadow-amber-500/40 hover:scale-105 transition-all duration-300"
          >
            <Play className="w-5 h-5" />
            Begin Training Now
          </button>
        </div>
      </div>
    </div>
  );
}
