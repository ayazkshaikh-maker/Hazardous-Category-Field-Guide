import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Award, Download, Shield, Printer } from 'lucide-react';
import html2canvas from 'html2canvas';
import { supabase } from '../lib/supabase';
import { isAdminSession } from '../lib/adminAuth';
import AdminModal from '../components/AdminModal';

const LOGO = '/Altasnim_Logo.png';

export default function CertificatePage() {
  const navigate = useNavigate();
  const certRef = useRef<HTMLDivElement>(null);
  const [isAdmin, setIsAdmin] = useState(isAdminSession());
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [approved, setApproved] = useState(false);
  const [saving, setSaving] = useState(false);

  const [fields, setFields] = useState({
    traineeName: '',
    employeeId: '',
    issueDate: new Date().toISOString().split('T')[0],
    certificateNumber: `HH-${Date.now().toString().slice(-6)}`,
    trainingScore: '100',
    issuedBy: '',
  });

  function update(field: string, value: string) {
    setFields((prev) => ({ ...prev, [field]: value }));
  }

  async function handleApproveAndSave() {
    if (!isAdmin) { setShowAdminModal(true); return; }
    if (!fields.traineeName.trim()) return;
    setSaving(true);
    await supabase.from('certificates').insert({
      trainee_name: fields.traineeName,
      employee_id: fields.employeeId,
      issue_date: fields.issueDate,
      certificate_number: fields.certificateNumber,
      training_score: parseInt(fields.trainingScore) || 0,
      issued_by: fields.issuedBy,
    });
    setApproved(true);
    setSaving(false);
  }

  async function handleDownload() {
    if (!certRef.current) return;
    const canvas = await html2canvas(certRef.current, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
    });
    const link = document.createElement('a');
    link.download = `Certificate-${fields.traineeName || 'trainee'}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }

  function handlePrint() {
    window.print();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-orange-50/20">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-20 print:hidden">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={() => navigate('/categories')} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium text-sm">Back</span>
          </button>
          <img src={LOGO} alt="Al Tasnim" className="h-10 w-auto object-contain" />
          <div className="flex items-center gap-2">
            {isAdmin ? (
              <span className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-semibold text-amber-700 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Admin
              </span>
            ) : (
              <button onClick={() => setShowAdminModal(true)} className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" /> Admin
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-10">
        {/* Editable fields */}
        {!approved && (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 mb-8 print:hidden">
            <h3 className="text-lg font-bold text-[#2b3d6b] mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-[#e88c2a]" />
              Certificate Details
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Trainee Name</label>
                <input type="text" value={fields.traineeName} onChange={(e) => update('traineeName', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" placeholder="Full name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Employee ID</label>
                <input type="text" value={fields.employeeId} onChange={(e) => update('employeeId', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" placeholder="ID number" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Issue Date</label>
                <input type="date" value={fields.issueDate} onChange={(e) => update('issueDate', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Certificate Number</label>
                <input type="text" value={fields.certificateNumber} onChange={(e) => update('certificateNumber', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Training Score (%)</label>
                <input type="number" min="0" max="100" value={fields.trainingScore} onChange={(e) => update('trainingScore', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Issued By</label>
                <input type="text" value={fields.issuedBy} onChange={(e) => update('issuedBy', e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#e88c2a] focus:border-[#e88c2a] outline-none text-slate-800" placeholder="HSE Lead name" />
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <button
                onClick={handleApproveAndSave}
                disabled={!fields.traineeName.trim() || saving}
                className="px-6 py-2.5 bg-gradient-to-r from-[#2b3d6b] to-[#3a5299] text-white font-semibold rounded-xl hover:from-[#1e2d52] hover:to-[#2b3d6b] transition-all shadow-md shadow-[#2b3d6b]/20 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Approve & Issue Certificate'}
              </button>
            </div>
          </div>
        )}

        {/* Action buttons after approval */}
        {approved && (
          <div className="flex items-center justify-center gap-3 mb-6 print:hidden">
            <button onClick={handleDownload} className="flex items-center gap-2 px-5 py-2.5 bg-[#e88c2a] text-white font-semibold rounded-xl hover:bg-[#d47a1e] transition-colors shadow-md">
              <Download className="w-4 h-4" /> Download PNG
            </button>
            <button onClick={handlePrint} className="flex items-center gap-2 px-5 py-2.5 bg-[#2b3d6b] text-white font-semibold rounded-xl hover:bg-[#1e2d52] transition-colors shadow-md">
              <Printer className="w-4 h-4" /> Print
            </button>
          </div>
        )}

        {/* Certificate */}
        <div ref={certRef} className="bg-white rounded-2xl shadow-xl mx-auto max-w-3xl">
          <div className="p-3">
            {/* Outer border - navy */}
            <div className="border-[3px] border-[#2b3d6b]/30 rounded-xl p-2">
              {/* Inner border - orange/gold */}
              <div className="border-2 border-[#e88c2a]/30 rounded-lg p-8 sm:p-12 relative overflow-hidden">
                {/* Corner ornaments */}
                <div className="absolute top-4 left-4 w-16 h-16 border-t-[3px] border-l-[3px] border-[#e88c2a]/30 rounded-tl-lg" />
                <div className="absolute top-4 right-4 w-16 h-16 border-t-[3px] border-r-[3px] border-[#e88c2a]/30 rounded-tr-lg" />
                <div className="absolute bottom-4 left-4 w-16 h-16 border-b-[3px] border-l-[3px] border-[#e88c2a]/30 rounded-bl-lg" />
                <div className="absolute bottom-4 right-4 w-16 h-16 border-b-[3px] border-r-[3px] border-[#e88c2a]/30 rounded-br-lg" />

                {/* Watermark */}
                <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                  <img src={LOGO} alt="" className="w-[400px] h-[400px] object-contain" />
                </div>

                <div className="relative text-center space-y-6">
                  {/* Company logo */}
                  <div className="flex items-center justify-center">
                    <img src={LOGO} alt="Al Tasnim" className="h-20 w-auto object-contain" />
                  </div>

                  <p className="text-xs tracking-[0.3em] text-[#2b3d6b]/50 font-semibold uppercase">
                    Al Tasnim ODC NIMR C/31000000171
                  </p>

                  {/* Decorative line */}
                  <div className="flex items-center justify-center gap-3">
                    <div className="w-16 h-[2px] bg-gradient-to-r from-transparent to-[#e88c2a]/40" />
                    <div className="w-2 h-2 rounded-full bg-[#e88c2a]/40" />
                    <div className="w-16 h-[2px] bg-gradient-to-l from-transparent to-[#e88c2a]/40" />
                  </div>

                  {/* Title */}
                  <div>
                    <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#2b3d6b]">
                      CERTIFICATE
                    </h2>
                    <p className="text-lg text-[#2b3d6b]/60 font-medium mt-1">of Completion</p>
                  </div>

                  <div className="w-24 h-[2px] bg-gradient-to-r from-transparent via-[#e88c2a]/50 to-transparent mx-auto" />

                  <p className="text-sm text-slate-500">
                    This is to certify that
                  </p>

                  {/* Trainee name */}
                  <div className="py-2">
                    <p className="text-2xl sm:text-3xl font-bold text-[#2b3d6b] min-h-[2.5rem]">
                      {fields.traineeName || '___________________'}
                    </p>
                    {fields.employeeId && (
                      <p className="text-sm text-[#2b3d6b]/50 mt-1">Employee ID: {fields.employeeId}</p>
                    )}
                  </div>

                  <p className="text-sm text-slate-500 max-w-lg mx-auto leading-relaxed">
                    has successfully completed the <strong className="text-[#2b3d6b]">Hazard Hunt Training Program</strong> and has demonstrated competency in hazard identification, risk assessment, and safety awareness.
                  </p>

                  {/* Stats */}
                  <div className="flex items-center justify-center gap-8 py-2">
                    <div className="text-center">
                      <p className="text-[10px] text-[#2b3d6b]/40 uppercase tracking-wider font-semibold">Date</p>
                      <p className="font-bold text-[#2b3d6b] mt-0.5 text-sm">{fields.issueDate}</p>
                    </div>
                    <div className="w-px h-8 bg-[#2b3d6b]/10" />
                    <div className="text-center">
                      <p className="text-[10px] text-[#2b3d6b]/40 uppercase tracking-wider font-semibold">Score</p>
                      <p className="font-bold text-[#e88c2a] mt-0.5 text-sm">{fields.trainingScore}%</p>
                    </div>
                    <div className="w-px h-8 bg-[#2b3d6b]/10" />
                    <div className="text-center">
                      <p className="text-[10px] text-[#2b3d6b]/40 uppercase tracking-wider font-semibold">Cert. No.</p>
                      <p className="font-bold text-[#2b3d6b] mt-0.5 text-sm">{fields.certificateNumber}</p>
                    </div>
                  </div>

                  {/* Signatures and golden seal */}
                  <div className="pt-6 flex items-end justify-center gap-8 sm:gap-12">
                    <div className="text-center">
                      <p className="text-sm font-medium text-[#2b3d6b] mb-1">{fields.issuedBy || '_______________'}</p>
                      <div className="w-36 border-b-2 border-[#2b3d6b]/20 mb-1" />
                      <p className="text-xs text-[#2b3d6b]/40 font-semibold">HSE Lead</p>
                    </div>

                    {/* Golden foil seal */}
                    <div className="relative w-24 h-24 shrink-0">
                      {/* Outer starburst ring */}
                      <div className="absolute inset-0 rounded-full" style={{
                        background: 'conic-gradient(from 0deg, #d4a012, #f5d060, #d4a012, #f5d060, #d4a012, #f5d060, #d4a012, #f5d060, #d4a012)',
                      }} />
                      {/* Mid ring */}
                      <div className="absolute inset-[3px] rounded-full bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-600 shadow-inner" />
                      {/* Inner circle */}
                      <div className="absolute inset-[6px] rounded-full bg-gradient-to-br from-yellow-200 via-amber-300 to-yellow-500 flex items-center justify-center shadow-inner">
                        <div className="text-center">
                          <Award className="w-6 h-6 text-amber-900/80 mx-auto" />
                          <p className="text-[6px] font-extrabold text-amber-900/80 mt-0.5 tracking-[0.15em] uppercase">Certified</p>
                          <p className="text-[5px] font-bold text-amber-800/60 tracking-wider">HSE</p>
                        </div>
                      </div>
                      {/* Shimmer overlay */}
                      <div className="absolute inset-[6px] rounded-full bg-gradient-to-tr from-white/30 via-transparent to-white/10 pointer-events-none" />
                    </div>

                    <div className="text-center">
                      <p className="text-sm font-medium text-[#2b3d6b] mb-1">_______________</p>
                      <div className="w-36 border-b-2 border-[#2b3d6b]/20 mb-1" />
                      <p className="text-xs text-[#2b3d6b]/40 font-semibold">Project Manager</p>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="pt-4 flex items-center justify-center gap-2">
                    <div className="w-12 h-[1px] bg-[#2b3d6b]/10" />
                    <p className="text-[9px] text-[#2b3d6b]/30 font-semibold tracking-wider">
                      HAZARD HUNT TRAINING PROGRAM | AL TASNIM ODC NIMR
                    </p>
                    <div className="w-12 h-[1px] bg-[#2b3d6b]/10" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AdminModal isOpen={showAdminModal} onClose={() => setShowAdminModal(false)} onAuthenticated={() => { setIsAdmin(true); setShowAdminModal(false); }} />
    </div>
  );
}
