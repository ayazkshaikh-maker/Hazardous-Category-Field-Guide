const ADMIN_PASSWORD = 'HazardHunt@2024';

export function verifyAdminPassword(password: string): boolean {
  return password === ADMIN_PASSWORD;
}

export function isAdminSession(): boolean {
  const session = sessionStorage.getItem('admin_authenticated');
  return session === 'true';
}

export function setAdminSession(): void {
  sessionStorage.setItem('admin_authenticated', 'true');
}

export function clearAdminSession(): void {
  sessionStorage.removeItem('admin_authenticated');
}
