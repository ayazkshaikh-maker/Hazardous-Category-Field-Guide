interface ProgressData {
  viewedScenarios: string[];
  completedCategories: string[];
}

function getProgress(): ProgressData {
  const raw = localStorage.getItem('training_progress');
  if (!raw) return { viewedScenarios: [], completedCategories: [] };
  return JSON.parse(raw);
}

function saveProgress(data: ProgressData): void {
  localStorage.setItem('training_progress', JSON.stringify(data));
}

export function markScenarioViewed(scenarioId: string): void {
  const progress = getProgress();
  if (!progress.viewedScenarios.includes(scenarioId)) {
    progress.viewedScenarios.push(scenarioId);
    saveProgress(progress);
  }
}

export function markCategoryCompleted(categoryId: string): void {
  const progress = getProgress();
  if (!progress.completedCategories.includes(categoryId)) {
    progress.completedCategories.push(categoryId);
    saveProgress(progress);
  }
}

export function isScenarioViewed(scenarioId: string): boolean {
  return getProgress().viewedScenarios.includes(scenarioId);
}

export function isCategoryCompleted(categoryId: string): boolean {
  return getProgress().completedCategories.includes(categoryId);
}

export function getCompletedCategoriesCount(): number {
  return getProgress().completedCategories.length;
}

export function getViewedScenariosCount(): number {
  return getProgress().viewedScenarios.length;
}

export function getViewedScenarioIds(): string[] {
  return getProgress().viewedScenarios;
}

export function resetProgress(): void {
  localStorage.removeItem('training_progress');
}
