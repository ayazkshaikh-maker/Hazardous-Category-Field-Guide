import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import IntroductionPage from './pages/IntroductionPage';
import CategoriesPage from './pages/CategoriesPage';
import CategoryScenariosPage from './pages/CategoryScenariosPage';
import CertificatePage from './pages/CertificatePage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/introduction" element={<IntroductionPage />} />
        <Route path="/categories" element={<CategoriesPage />} />
        <Route path="/category/:categoryId" element={<CategoryScenariosPage />} />
        <Route path="/certificate" element={<CertificatePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
