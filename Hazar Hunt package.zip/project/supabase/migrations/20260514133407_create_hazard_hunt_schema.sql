/*
  # Hazard Hunt Training Platform Schema

  1. New Tables
    - `categories` - Training categories (Civil, Mechanical, etc.)
      - `id` (uuid, primary key)
      - `name` (text) - Category display name
      - `icon` (text) - Icon identifier
      - `order_index` (integer) - Display order
      - `created_at` (timestamptz)
    - `scenarios` - Training scenarios within categories
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key -> categories)
      - `title` (text) - Scenario title
      - `description` (text) - Scenario description
      - `unsafe_explanation` (text)
      - `safe_explanation` (text)
      - `lessons_learned` (text)
      - `hazard_indicators` (text)
      - `ppe_requirements` (text)
      - `control_measures` (text)
      - `unsafe_image_url` (text)
      - `safe_image_url` (text)
      - `order_index` (integer)
      - `created_at` (timestamptz)
    - `certificates` - Issued certificates
      - `id` (uuid, primary key)
      - `trainee_name` (text)
      - `employee_id` (text)
      - `issue_date` (date)
      - `certificate_number` (text)
      - `training_score` (integer)
      - `issued_by` (text)
      - `created_at` (timestamptz)

  2. Security
    - RLS enabled on all tables
    - Policies allow anon read access for categories and scenarios (public training platform)
    - Certificates require anon key for insert/select (no auth required for this training app)
*/

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  icon text NOT NULL DEFAULT 'HardHat',
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to categories"
  ON categories FOR SELECT
  TO anon
  USING (order_index >= 0);

CREATE POLICY "Allow anon insert categories"
  ON categories FOR INSERT
  TO anon
  WITH CHECK (name IS NOT NULL AND name != '');

CREATE POLICY "Allow anon update categories"
  ON categories FOR UPDATE
  TO anon
  USING (order_index >= 0)
  WITH CHECK (name IS NOT NULL AND name != '');

CREATE POLICY "Allow anon delete categories"
  ON categories FOR DELETE
  TO anon
  USING (order_index >= 0);

-- Scenarios table
CREATE TABLE IF NOT EXISTS scenarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  unsafe_explanation text NOT NULL DEFAULT '',
  safe_explanation text NOT NULL DEFAULT '',
  lessons_learned text NOT NULL DEFAULT '',
  hazard_indicators text NOT NULL DEFAULT '',
  ppe_requirements text NOT NULL DEFAULT '',
  control_measures text NOT NULL DEFAULT '',
  unsafe_image_url text NOT NULL DEFAULT '',
  safe_image_url text NOT NULL DEFAULT '',
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE scenarios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to scenarios"
  ON scenarios FOR SELECT
  TO anon
  USING (order_index >= 0);

CREATE POLICY "Allow anon insert scenarios"
  ON scenarios FOR INSERT
  TO anon
  WITH CHECK (title IS NOT NULL AND title != '');

CREATE POLICY "Allow anon update scenarios"
  ON scenarios FOR UPDATE
  TO anon
  USING (order_index >= 0)
  WITH CHECK (title IS NOT NULL AND title != '');

CREATE POLICY "Allow anon delete scenarios"
  ON scenarios FOR DELETE
  TO anon
  USING (order_index >= 0);

-- Certificates table
CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trainee_name text NOT NULL,
  employee_id text NOT NULL DEFAULT '',
  issue_date date NOT NULL DEFAULT CURRENT_DATE,
  certificate_number text NOT NULL DEFAULT '',
  training_score integer NOT NULL DEFAULT 0,
  issued_by text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anon read certificates"
  ON certificates FOR SELECT
  TO anon
  USING (trainee_name IS NOT NULL);

CREATE POLICY "Allow anon insert certificates"
  ON certificates FOR INSERT
  TO anon
  WITH CHECK (trainee_name IS NOT NULL AND trainee_name != '');

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_categories_order ON categories(order_index);
CREATE INDEX IF NOT EXISTS idx_scenarios_category ON scenarios(category_id);
CREATE INDEX IF NOT EXISTS idx_scenarios_order ON scenarios(category_id, order_index);
CREATE INDEX IF NOT EXISTS idx_certificates_number ON certificates(certificate_number);
